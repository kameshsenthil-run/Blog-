# BlogSphere — Blog Platform with Comments

A complete, production-ready full-stack blog platform with JWT authentication, post management, and a commenting system.

**Tech Stack**
- Frontend: HTML5, CSS3, Vanilla JavaScript
- Backend: Node.js, Express.js
- Database: MongoDB with Mongoose
- Auth: JWT + bcrypt password hashing

---

## 📁 Folder Structure

```
blog-platform/
│
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── .env.example
│   ├── config/
│   │   └── db.js
│   ├── middleware/
│   │   └── auth.js
│   ├── models/
│   │   ├── User.js
│   │   ├── Post.js
│   │   └── Comment.js
│   └── routes/
│       ├── authRoutes.js
│       ├── postRoutes.js
│       └── commentRoutes.js
│
├── frontend/
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── post.html
│   ├── create-post.html
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── auth.js
│       ├── posts.js
│       └── comments.js
│
└── README.md
```

---

## 🗄️ 1. MongoDB Setup

You can use either a **local MongoDB instance** or **MongoDB Atlas** (cloud).

### Option A: Local MongoDB
1. Install MongoDB Community Server: https://www.mongodb.com/try/download/community
2. Start the MongoDB service:
   ```bash
   # macOS (with brew services)
   brew services start mongodb-community

   # Linux
   sudo systemctl start mongod

   # Windows
   net start MongoDB
   ```
3. Your connection string will be:
   ```
   mongodb://127.0.0.1:27017/blog-platform
   ```

### Option B: MongoDB Atlas (Cloud)
1. Create a free cluster at https://www.mongodb.com/cloud/atlas
2. Create a database user (username/password)
3. Whitelist your IP address (or `0.0.0.0/0` for development)
4. Get your connection string, it will look like:
   ```
   mongodb+srv://<username>:<password>@cluster0.mongodb.net/blog-platform
   ```

---

## ⚙️ 2. Backend Installation & Setup

```bash
# Navigate to the backend folder
cd blog-platform/backend

# Install dependencies
npm install

# Create your .env file from the example
cp .env.example .env
```

Now edit `.env` and set your own values:

```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/blog-platform
JWT_SECRET=your_super_secret_jwt_key_change_this_in_production
JWT_EXPIRES_IN=7d
```

### Run the backend server

```bash
# Development mode (auto-restarts on file changes, requires nodemon)
npm run dev

# OR Production mode
npm start
```

The API will be running at: **http://localhost:5000**

You should see in your terminal:
```
MongoDB Connected: 127.0.0.1
Server running on http://localhost:5000
```

---

## 🌐 3. Frontend Setup & Run Instructions

The frontend is built with plain HTML/CSS/JS — no build step or bundler required. However, it's best served through a local static server (rather than opening the file directly) so that things like relative paths and fetch requests behave properly.

### Option A: VS Code "Live Server" extension (easiest)
1. Open the `frontend` folder in VS Code
2. Right-click `index.html` → "Open with Live Server"
3. It will open at something like `http://127.0.0.1:5500`

### Option B: Using Node's `http-server` package
```bash
cd blog-platform/frontend
npx http-server -p 5500
```
Then visit: **http://localhost:5500**

### Option C: Using Python's built-in server
```bash
cd blog-platform/frontend
python3 -m http.server 5500
```
Then visit: **http://localhost:5500**

> ⚠️ Make sure the backend server (port 5000) is running at the same time, since the frontend calls `http://localhost:5000/api` for all data. If you change the backend port, update `API_BASE_URL` in `frontend/js/auth.js`.

---

## 🔑 4. Sample `.env` File

Located at `backend/.env.example` — copy it to `backend/.env`:

```env
# Server port
PORT=5000

# MongoDB connection string
MONGO_URI=mongodb://127.0.0.1:27017/blog-platform

# JWT secret key (use a long random string in production)
JWT_SECRET=your_super_secret_jwt_key_change_this_in_production

# JWT token expiry
JWT_EXPIRES_IN=7d
```

---

## 📡 5. API Routes Reference

### Auth
| Method | Endpoint              | Access  | Description         |
|--------|------------------------|---------|----------------------|
| POST   | `/api/auth/register`   | Public  | Register new user   |
| POST   | `/api/auth/login`      | Public  | Login existing user |

### Posts
| Method | Endpoint           | Access            | Description           |
|--------|----------------------|-------------------|------------------------|
| GET    | `/api/posts`         | Public            | Get all posts         |
| GET    | `/api/posts/:id`     | Public            | Get a single post     |
| POST   | `/api/posts`         | Private (JWT)     | Create a new post     |
| PUT    | `/api/posts/:id`     | Private (Author)  | Update own post        |
| DELETE | `/api/posts/:id`     | Private (Author)  | Delete own post        |

### Comments
| Method | Endpoint                  | Access              | Description              |
|--------|-----------------------------|---------------------|----------------------------|
| GET    | `/api/comments/:postId`    | Public              | Get all comments for a post |
| POST   | `/api/comments/:postId`    | Private (JWT)       | Add a comment to a post   |
| DELETE | `/api/comments/:id`        | Private (Owner)     | Delete own comment        |

All private routes require an `Authorization: Bearer <token>` header.

---

## 🧪 6. Quick Test Flow

1. Start MongoDB (local or confirm Atlas is reachable)
2. Start backend: `cd backend && npm run dev`
3. Start frontend: `cd frontend && npx http-server -p 5500`
4. Open `http://localhost:5500` in your browser
5. Click **Sign Up** → create an account
6. You'll be redirected to your **Dashboard**
7. Click **+ New Post** → write and publish a post
8. View it from the homepage, add a comment, and try editing/deleting it

---

## 🎨 Design Notes

- Clean blue (`#2563eb`) and white theme throughout
- Fully responsive: desktop (3-column grid), tablet (2-column), mobile (1-column, collapsible navbar)
- Card-based layout with hover animations on posts and buttons
- Client-side route protection: `dashboard.html` and `create-post.html` redirect unauthenticated users to `login.html`
- All user-generated content is HTML-escaped before rendering to prevent XSS

## 🔒 Security Notes

- Passwords are hashed with bcrypt (10 salt rounds) before storage — plaintext passwords are never saved
- JWT tokens are signed with a server-side secret and expire after 7 days by default
- Only the author of a post can edit/delete it; only the owner of a comment can delete it (enforced server-side, not just hidden in the UI)
- CORS is enabled on the backend so the frontend (different port) can communicate with the API

---

## 🛠️ Troubleshooting

- **"MongoDB connection error"** → Confirm MongoDB is running and `MONGO_URI` in `.env` is correct.
- **CORS errors in browser console** → Ensure backend is running and `cors()` middleware is active in `server.js`.
- **"Not authorized, token invalid or expired"** → Log out and log back in to get a fresh token.
- **Posts/comments not showing** → Open browser dev tools → Network tab → confirm requests are hitting `http://localhost:5000/api/...` and returning 200 status codes.
