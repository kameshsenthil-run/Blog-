// routes/postRoutes.js
// Routes: GET /api/posts, GET /api/posts/:id, POST /api/posts, PUT /api/posts/:id, DELETE /api/posts/:id

const express = require('express');
const Post = require('../models/Post');
const Comment = require('../models/Comment');
const { protect } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/posts
// @desc    Get all blog posts (newest first), with author info populated
// @access  Public
router.get('/', async (req, res) => {
  try {
    const posts = await Post.find()
      .populate('author', 'name email')
      .sort({ createdAt: -1 });

    res.status(200).json(posts);
  } catch (error) {
    console.error('Get posts error:', error.message);
    res.status(500).json({ message: 'Server error while fetching posts' });
  }
});

// @route   GET /api/posts/:id
// @desc    Get a single blog post by id
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate('author', 'name email');

    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    res.status(200).json(post);
  } catch (error) {
    console.error('Get single post error:', error.message);
    // Handle invalid ObjectId format gracefully
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ message: 'Post not found' });
    }
    res.status(500).json({ message: 'Server error while fetching post' });
  }
});

// @route   POST /api/posts
// @desc    Create a new blog post
// @access  Private (requires JWT)
router.post('/', protect, async (req, res) => {
  try {
    const { title, content } = req.body;

    if (!title || !content) {
      return res.status(400).json({ message: 'Please provide title and content' });
    }

    const post = await Post.create({
      title,
      content,
      author: req.user._id, // comes from auth middleware
    });

    const populatedPost = await post.populate('author', 'name email');

    res.status(201).json(populatedPost);
  } catch (error) {
    console.error('Create post error:', error.message);
    res.status(500).json({ message: 'Server error while creating post' });
  }
});

// @route   PUT /api/posts/:id
// @desc    Update an existing blog post
// @access  Private (only the author can edit)
router.put('/:id', protect, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    // Only the author of the post can update it
    if (post.author.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to edit this post' });
    }

    const { title, content } = req.body;
    post.title = title || post.title;
    post.content = content || post.content;

    const updatedPost = await post.save();
    const populatedPost = await updatedPost.populate('author', 'name email');

    res.status(200).json(populatedPost);
  } catch (error) {
    console.error('Update post error:', error.message);
    res.status(500).json({ message: 'Server error while updating post' });
  }
});

// @route   DELETE /api/posts/:id
// @desc    Delete a blog post (and its comments)
// @access  Private (only the author can delete)
router.delete('/:id', protect, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    // Only the author of the post can delete it
    if (post.author.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to delete this post' });
    }

    // Delete all comments associated with this post first
    await Comment.deleteMany({ post: post._id });

    // Delete the post itself
    await post.deleteOne();

    res.status(200).json({ message: 'Post deleted successfully' });
  } catch (error) {
    console.error('Delete post error:', error.message);
    res.status(500).json({ message: 'Server error while deleting post' });
  }
});

module.exports = router;
