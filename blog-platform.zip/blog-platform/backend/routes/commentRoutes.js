// routes/commentRoutes.js
// Routes: GET /api/comments/:postId, POST /api/comments/:postId, DELETE /api/comments/:id

const express = require('express');
const Comment = require('../models/Comment');
const Post = require('../models/Post');
const { protect } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/comments/:postId
// @desc    Get all comments for a specific post
// @access  Public
router.get('/:postId', async (req, res) => {
  try {
    const comments = await Comment.find({ post: req.params.postId })
      .populate('user', 'name email')
      .sort({ createdAt: -1 });

    res.status(200).json(comments);
  } catch (error) {
    console.error('Get comments error:', error.message);
    res.status(500).json({ message: 'Server error while fetching comments' });
  }
});

// @route   POST /api/comments/:postId
// @desc    Add a comment to a post
// @access  Private (requires JWT)
router.post('/:postId', protect, async (req, res) => {
  try {
    const { comment } = req.body;

    if (!comment || comment.trim() === '') {
      return res.status(400).json({ message: 'Comment text is required' });
    }

    // Verify the post exists before attaching a comment to it
    const post = await Post.findById(req.params.postId);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    const newComment = await Comment.create({
      post: req.params.postId,
      user: req.user._id,
      comment,
    });

    const populatedComment = await newComment.populate('user', 'name email');

    res.status(201).json(populatedComment);
  } catch (error) {
    console.error('Add comment error:', error.message);
    res.status(500).json({ message: 'Server error while adding comment' });
  }
});

// @route   DELETE /api/comments/:id
// @desc    Delete own comment
// @access  Private (only the comment owner can delete)
router.delete('/:id', protect, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);

    if (!comment) {
      return res.status(404).json({ message: 'Comment not found' });
    }

    // Only the user who wrote the comment can delete it
    if (comment.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to delete this comment' });
    }

    await comment.deleteOne();

    res.status(200).json({ message: 'Comment deleted successfully' });
  } catch (error) {
    console.error('Delete comment error:', error.message);
    res.status(500).json({ message: 'Server error while deleting comment' });
  }
});

module.exports = router;
