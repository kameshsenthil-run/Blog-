// models/Comment.js
// Mongoose schema/model for Comment collection

const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema({
  post: {
    // Reference to the Post this comment belongs to
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Post',
    required: true,
  },
  user: {
    // Reference to the User who wrote the comment
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  comment: {
    type: String,
    required: [true, 'Comment text is required'],
    trim: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('Comment', commentSchema);
