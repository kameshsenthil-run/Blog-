// js/comments.js
// Handles comment operations: load comments, add comment, delete own comment.

// ---------- Load Comments for a Post ----------
async function loadComments(postId) {
  const commentList = document.getElementById('commentList');
  if (!commentList) return;

  try {
    const response = await fetch(`${API_BASE_URL}/comments/${postId}`);
    const comments = await response.json();

    if (!response.ok) {
      throw new Error(comments.message || 'Failed to load comments');
    }

    renderComments(comments);
  } catch (error) {
    commentList.innerHTML = `<p class="no-comments">${escapeHTML(error.message)}</p>`;
  }
}

// Render the list of comments, with delete button for the comment owner
function renderComments(comments) {
  const commentList = document.getElementById('commentList');
  const currentUser = getUser();

  if (comments.length === 0) {
    commentList.innerHTML = '<p class="no-comments">No comments yet. Be the first to comment!</p>';
    return;
  }

  commentList.innerHTML = comments
    .map((c) => {
      const isOwner = currentUser && c.user && currentUser.id === c.user._id;
      return `
        <div class="comment-item" data-id="${c._id}">
          <div class="comment-item-header">
            <span class="comment-author">${escapeHTML(c.user ? c.user.name : 'Unknown')}</span>
            <span class="comment-date">${formatDate(c.createdAt)}</span>
          </div>
          <p class="comment-text">${escapeHTML(c.comment)}</p>
          ${
            isOwner
              ? `<button class="comment-delete-btn" data-id="${c._id}">Delete</button>`
              : ''
          }
        </div>
      `;
    })
    .join('');

  // Attach delete handlers to each delete button
  document.querySelectorAll('.comment-delete-btn').forEach((btn) => {
    btn.addEventListener('click', () => deleteComment(btn.dataset.id));
  });
}

// ---------- Add a New Comment ----------
function setupCommentForm() {
  const form = document.getElementById('commentForm');
  if (!form) return;

  const urlParams = new URLSearchParams(window.location.search);
  const postId = urlParams.get('id');

  // If user is not logged in, hide the comment form and show a login prompt
  if (!isLoggedIn()) {
    form.outerHTML = '<p class="no-comments"><a href="login.html">Login</a> to leave a comment.</p>';
    return;
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const textarea = document.getElementById('commentText');
    const comment = textarea.value.trim();
    const submitBtn = form.querySelector('button[type="submit"]');

    if (!comment) return;

    try {
      submitBtn.disabled = true;
      submitBtn.textContent = 'Posting...';

      const response = await fetch(`${API_BASE_URL}/comments/${postId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${getToken()}`,
        },
        body: JSON.stringify({ comment }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Failed to post comment');
      }

      textarea.value = '';
      loadComments(postId); // refresh comment list
    } catch (error) {
      alert(error.message);
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Post Comment';
    }
  });
}

// ---------- Delete a Comment ----------
async function deleteComment(commentId) {
  if (!confirm('Delete this comment?')) return;

  const urlParams = new URLSearchParams(window.location.search);
  const postId = urlParams.get('id');

  try {
    const response = await fetch(`${API_BASE_URL}/comments/${commentId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${getToken()}` },
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'Failed to delete comment');
    }

    loadComments(postId); // refresh comment list
  } catch (error) {
    alert(error.message);
  }
}

// ---------- Initialize on Post Detail Page ----------
document.addEventListener('DOMContentLoaded', () => {
  setupCommentForm();
});
