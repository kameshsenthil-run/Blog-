// js/posts.js
// Handles all blog post related operations:
// fetching all posts, single post, create, edit, delete, and rendering.

// Format an ISO date string into a readable "Month Day, Year, hh:mm AM/PM" format
function formatDate(dateString) {
  const options = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  };
  return new Date(dateString).toLocaleDateString('en-US', options);
}

// Create a short excerpt from post content for card previews
function getExcerpt(content, maxLength = 140) {
  if (content.length <= maxLength) return content;
  return content.substring(0, maxLength).trim() + '...';
}

// Escape HTML to prevent XSS when injecting user content into the DOM
function escapeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ---------- Fetch All Posts (Homepage) ----------
async function loadAllPosts() {
  const grid = document.getElementById('postsGrid');
  if (!grid) return;

  try {
    const response = await fetch(`${API_BASE_URL}/posts`);
    const posts = await response.json();

    if (!response.ok) {
      throw new Error(posts.message || 'Failed to load posts');
    }

    if (posts.length === 0) {
      grid.innerHTML = '<p class="empty-state">No blog posts yet. Be the first to write one!</p>';
      return;
    }

    grid.innerHTML = posts.map(renderPostCard).join('');
  } catch (error) {
    grid.innerHTML = `<p class="empty-state">Error loading posts: ${escapeHTML(error.message)}</p>`;
  }
}

// Render a single post card (used on homepage)
function renderPostCard(post) {
  const authorName = post.author ? escapeHTML(post.author.name) : 'Unknown';
  return `
    <div class="post-card">
      <h3>${escapeHTML(post.title)}</h3>
      <p class="post-excerpt">${escapeHTML(getExcerpt(post.content))}</p>
      <div class="post-meta">
        <span class="author-name">${authorName}</span>
        <span>${formatDate(post.createdAt)}</span>
      </div>
      <a href="post.html?id=${post._id}" class="btn btn-outline btn-sm">Read More</a>
    </div>
  `;
}

// ---------- Fetch Single Post (Post Detail Page) ----------
async function loadSinglePost() {
  const container = document.getElementById('postDetail');
  if (!container) return;

  const urlParams = new URLSearchParams(window.location.search);
  const postId = urlParams.get('id');

  if (!postId) {
    container.innerHTML = '<p class="empty-state">No post specified.</p>';
    return;
  }

  try {
    const response = await fetch(`${API_BASE_URL}/posts/${postId}`);
    const post = await response.json();

    if (!response.ok) {
      throw new Error(post.message || 'Post not found');
    }

    const currentUser = getUser();
    const isOwner = currentUser && post.author && currentUser.id === post.author._id;

    container.innerHTML = `
      <h1>${escapeHTML(post.title)}</h1>
      <div class="post-meta">
        <span>By <span class="author-name">${escapeHTML(post.author ? post.author.name : 'Unknown')}</span></span>
        <span>${formatDate(post.createdAt)}</span>
      </div>
      <div class="post-body">${escapeHTML(post.content)}</div>
      ${
        isOwner
          ? `<div class="post-detail-actions">
               <a href="create-post.html?edit=${post._id}" class="btn btn-primary">Edit Post</a>
               <button id="deletePostBtn" class="btn btn-danger" data-id="${post._id}">Delete Post</button>
             </div>`
          : ''
      }
    `;

    // Attach delete handler if owner
    const deleteBtn = document.getElementById('deletePostBtn');
    if (deleteBtn) {
      deleteBtn.addEventListener('click', () => deletePost(postId));
    }

    // Load comments for this post (function defined in comments.js)
    if (typeof loadComments === 'function') {
      loadComments(postId);
    }
  } catch (error) {
    container.innerHTML = `<p class="empty-state">${escapeHTML(error.message)}</p>`;
  }
}

// ---------- Delete Post ----------
async function deletePost(postId) {
  if (!confirm('Are you sure you want to delete this post? This action cannot be undone.')) {
    return;
  }

  try {
    const response = await fetch(`${API_BASE_URL}/posts/${postId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${getToken()}` },
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'Failed to delete post');
    }

    alert('Post deleted successfully');
    window.location.href = 'dashboard.html';
  } catch (error) {
    alert(error.message);
  }
}

// ---------- Load User's Own Posts (Dashboard) ----------
async function loadUserPosts() {
  const list = document.getElementById('dashboardList');
  if (!list) return;

  const currentUser = getUser();
  if (!currentUser) return;

  try {
    const response = await fetch(`${API_BASE_URL}/posts`);
    const posts = await response.json();

    if (!response.ok) {
      throw new Error(posts.message || 'Failed to load posts');
    }

    // Filter posts to only those authored by the current logged-in user
    const myPosts = posts.filter((post) => post.author && post.author._id === currentUser.id);

    if (myPosts.length === 0) {
      list.innerHTML = '<p class="empty-state">You haven\'t written any posts yet. Click "New Post" to get started!</p>';
      return;
    }

    list.innerHTML = myPosts.map(renderDashboardItem).join('');

    // Attach delete handlers
    document.querySelectorAll('.dashboard-delete-btn').forEach((btn) => {
      btn.addEventListener('click', () => deletePost(btn.dataset.id).then(() => loadUserPosts()));
    });
  } catch (error) {
    list.innerHTML = `<p class="empty-state">${escapeHTML(error.message)}</p>`;
  }
}

// Render a single dashboard list item for the user's own post
function renderDashboardItem(post) {
  return `
    <div class="dashboard-post-item">
      <div class="dashboard-post-info">
        <h3>${escapeHTML(post.title)}</h3>
        <span class="post-date">Last updated: ${formatDate(post.updatedAt)}</span>
      </div>
      <div class="dashboard-post-actions">
        <a href="post.html?id=${post._id}" class="btn btn-outline btn-sm">View</a>
        <a href="create-post.html?edit=${post._id}" class="btn btn-primary btn-sm">Edit</a>
        <button class="btn btn-danger btn-sm dashboard-delete-btn" data-id="${post._id}">Delete</button>
      </div>
    </div>
  `;
}

// ---------- Create / Edit Post Form Handler ----------
async function setupPostForm() {
  const form = document.getElementById('postForm');
  if (!form) return;

  const urlParams = new URLSearchParams(window.location.search);
  const editId = urlParams.get('edit');
  const titleInput = document.getElementById('title');
  const contentInput = document.getElementById('content');
  const formHeading = document.getElementById('formHeading');
  const submitBtn = document.getElementById('postSubmitBtn');

  // If editing, pre-fill the form with existing post data
  if (editId) {
    if (formHeading) formHeading.textContent = 'Edit Post';
    if (submitBtn) submitBtn.textContent = 'Update Post';

    try {
      const response = await fetch(`${API_BASE_URL}/posts/${editId}`);
      const post = await response.json();

      if (!response.ok) {
        throw new Error(post.message || 'Failed to load post');
      }

      titleInput.value = post.title;
      contentInput.value = post.content;
    } catch (error) {
      showAlert('postFormAlert', error.message, 'error');
    }
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const title = titleInput.value.trim();
    const content = contentInput.value.trim();

    if (!title || !content) {
      showAlert('postFormAlert', 'Please fill in both title and content', 'error');
      return;
    }

    try {
      submitBtn.disabled = true;
      submitBtn.textContent = editId ? 'Updating...' : 'Publishing...';

      const url = editId ? `${API_BASE_URL}/posts/${editId}` : `${API_BASE_URL}/posts`;
      const method = editId ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${getToken()}`,
        },
        body: JSON.stringify({ title, content }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Failed to save post');
      }

      // Redirect to the post detail page after success
      window.location.href = `post.html?id=${data._id}`;
    } catch (error) {
      showAlert('postFormAlert', error.message, 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = editId ? 'Update Post' : 'Publish Post';
    }
  });
}

// ---------- Initialize Based on Current Page ----------
document.addEventListener('DOMContentLoaded', () => {
  loadAllPosts();
  loadSinglePost();
  loadUserPosts();
  setupPostForm();
});
