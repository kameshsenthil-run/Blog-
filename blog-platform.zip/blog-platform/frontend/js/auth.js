// js/auth.js
// Handles authentication: register, login, logout, and navbar UI state.
// Token and user info are stored in localStorage.

// Base URL of the backend API
const API_BASE_URL = 'http://localhost:5000/api';

// ---------- Local Storage Helpers ----------

// Save JWT token and user info after successful login/register
function saveAuth(token, user) {
  localStorage.setItem('token', token);
  localStorage.setItem('user', JSON.stringify(user));
}

// Retrieve the stored JWT token
function getToken() {
  return localStorage.getItem('token');
}

// Retrieve the stored logged-in user object
function getUser() {
  const userStr = localStorage.getItem('user');
  return userStr ? JSON.parse(userStr) : null;
}

// Clear auth data (used on logout)
function clearAuth() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
}

// Check if a user is currently logged in
function isLoggedIn() {
  return !!getToken();
}

// ---------- Navbar UI State ----------
// Shows Login/Register links if logged out, or Dashboard/Logout if logged in.
function updateNavbar() {
  const navAuthLinks = document.getElementById('navAuthLinks');
  const navUserLinks = document.getElementById('navUserLinks');
  const navUserName = document.getElementById('navUserName');

  if (!navAuthLinks || !navUserLinks) return; // navbar elements not on this page

  if (isLoggedIn()) {
    const user = getUser();
    navAuthLinks.classList.add('hidden');
    navUserLinks.classList.remove('hidden');
    if (navUserName && user) {
      navUserName.textContent = `Hi, ${user.name}`;
    }
  } else {
    navAuthLinks.classList.remove('hidden');
    navUserLinks.classList.add('hidden');
  }
}

// Logs the user out and redirects to homepage
function logoutUser() {
  clearAuth();
  window.location.href = 'index.html';
}

// Toggles the mobile navbar menu
function setupNavToggle() {
  const toggleBtn = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');
  if (toggleBtn && navLinks) {
    toggleBtn.addEventListener('click', () => {
      navLinks.classList.toggle('show');
    });
  }
}

// Utility: show an alert message box (error or success)
function showAlert(elementId, message, type = 'error') {
  const alertBox = document.getElementById(elementId);
  if (!alertBox) return;
  alertBox.textContent = message;
  alertBox.className = `alert show alert-${type}`;
}

// ---------- Page Initialization ----------
document.addEventListener('DOMContentLoaded', () => {
  updateNavbar();
  setupNavToggle();

  // Attach logout handler if logout button exists
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      logoutUser();
    });
  }

  // ---------- Register Form Handler ----------
  const registerForm = document.getElementById('registerForm');
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      const submitBtn = registerForm.querySelector('button[type="submit"]');

      try {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Creating account...';

        const response = await fetch(`${API_BASE_URL}/auth/register`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, password }),
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || 'Registration failed');
        }

        // Save token & redirect to dashboard
        saveAuth(data.token, data.user);
        window.location.href = 'dashboard.html';
      } catch (error) {
        showAlert('authAlert', error.message, 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Create Account';
      }
    });
  }

  // ---------- Login Form Handler ----------
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      const submitBtn = loginForm.querySelector('button[type="submit"]');

      try {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Logging in...';

        const response = await fetch(`${API_BASE_URL}/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password }),
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || 'Login failed');
        }

        saveAuth(data.token, data.user);
        window.location.href = 'dashboard.html';
      } catch (error) {
        showAlert('authAlert', error.message, 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Login';
      }
    });
  }

  // ---------- Protect Pages That Require Login ----------
  // Pages with data-protected="true" on <body> redirect to login if not authenticated
  if (document.body.dataset.protected === 'true' && !isLoggedIn()) {
    window.location.href = 'login.html';
  }
});
